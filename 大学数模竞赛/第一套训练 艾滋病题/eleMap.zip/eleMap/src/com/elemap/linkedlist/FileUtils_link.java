package com.elemap.linkedlist;

import com.elemap.Main;
import com.elemap.Map;
import com.elemap.linkedlist.MapLinkedList.MapNode;
import com.elemap.list.MapList;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileUtils_link {


    /**
     * 读取文件
     * @param path
     * @throws Exception
     */
    public static void readFile(String path) throws Exception {
        InputStream is = new FileInputStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"GBK"));
        String str = null;

        int i=0;
        while (true) {
            str = reader.readLine();
            if(str!=null && ""!=str)
            {
                Map map=changeData(str);
                Main.mapLinkedList.insert(map,i);
            }
            else
                break;

            i++;
        }
        is.close();
    }

    public static void writeFile(String path) throws Exception {
    	File file = new File(path);
    	if (!file.exists()) {
    		file.createNewFile();
    	}
    	FileWriter writer = new FileWriter(file , true);
    	BufferedWriter out = new BufferedWriter(writer);
    	com.elemap.linkedlist.MapLinkedList.MapNode temp= Main.mapLinkedList.head;
    	while (temp!=null)
    	{
    		out.write("#" + temp.map.linkID + "; flag=" + temp.map.flag + "; branch=" + temp.map.branch + "; dispclass=" + temp.map.dispclass
    				+ "; roadname=" + temp.map.roadname + '\''+"\n");
    		temp = temp.next;
    	}
    	out.flush();
    	out.close();
    }
    
    private static class MapNode{
        Map map;
        MapNode next;
        public MapNode(Map map){
            this.map=map;
        }
    }
    /**
     *
     * @param str
     * @return
     */
    public static Map changeData(String str){
        String[] strMap=str.split(";");
        Map map=new Map();
        map.linkID=Integer.parseInt(strMap[0].substring(strMap[0].indexOf("=")+1));
        map.flag=Integer.parseInt(strMap[1].substring(strMap[1].indexOf("=")+1));
        map.branch=Integer.parseInt(strMap[2].substring(strMap[2].indexOf("=")+1));
        map.dispclass=Integer.parseInt(strMap[3].substring(strMap[3].indexOf("=")+1));
        map.roadname=strMap[4].substring(strMap[4].indexOf("=")+1);
        return map;
    }
}
