package com.elemap.linkedlist;

import java.util.Scanner;

import com.elemap.Map;

public class MapLinkedList {

    //头节点指针
    public MapNode head;
    //尾节点指针
    public MapNode last;
    //0表示没有排序,1表示已排序
    private int sort;
    //链表实际长度
    private int size;

    public MapLinkedList(){
        this.sort=0;
    }

    /**
     * 链表查找元素
     * @param index 查找的位置
     * @return 要查找的元素
     * @throws Exception
     */
    public MapNode get(int index) throws Exception {
        if(index<0 ||index>=size){
            throw  new IndexOutOfBoundsException("超出链表节点范围！");
        }
        MapNode temp=head;
        for (int i=0;i<index;i++){
            temp=temp.next;
        }
        return  temp;
    }

    public int getSize(){
        return  this.size;
    }

    public void insert()throws Exception{
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
        //建立新的插入对象
    	System.out.println("请输入建立对象的ID");
    	int id = 0,flag = 0,branch = 0,dispclass = 0;
    	int flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_ID=new Scanner(System.in).nextInt();
    		if(select_ID<=this.size)
        		System.out.println(select_ID+"已存在，请重新输入ID");
    		else
    			id = select_ID;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的有无道路名称标识");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_flag=new Scanner(System.in).nextInt();
    		if(select_flag!=0&&select_flag!=1)
        		System.out.println("只能是0或者1，请重新输入");
    		else
    			flag = select_flag;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的道路分叉口数");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_branch=new Scanner(System.in).nextInt();
    		if(select_branch>8||select_branch<0)
        		System.out.println("分岔路口只能是0~7，请重新输入");
    		else
    			branch = select_branch;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的番号");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_dispclass=new Scanner(System.in).nextInt();
    		if(select_dispclass>13||select_dispclass<0)
        		System.out.println("番号只能是0~13，请重新输入");
    		else
    			dispclass = select_dispclass;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的路名");
    	String select_roadname=new Scanner(System.in).nextLine();
    	Map temp = new Map(id,flag,branch,dispclass,select_roadname);
    	//这里自动采用尾插法 也就是index取值为size
    	insert(temp,size);
    	//插入过后可以再次排序
    	this.sort=0;
    }
    
    /**
     * 链表插入元素
     * @param map 插入元素
     * @param index 插入位置
     * @throws Exception
     */
    public  void insert(Map map, int index) throws  Exception{
        if(index<0 || index>size)
        {
            throw  new IndexOutOfBoundsException("超出链表节点范围！");
        }
        MapNode insertedNode=new MapNode(map);
        if(size==0){
            //空链表
            head=insertedNode;
            last=insertedNode;
        }else if(index==0){
            //插入头部
            insertedNode.next=head;
            head=insertedNode;
        }else if(size==index){
            //插入尾部
            last.next=insertedNode;
            last=insertedNode;
        }else {
            MapNode prevNode=get(index-1);
            insertedNode.next=prevNode.next;
            prevNode.next=insertedNode;
        }
        size++;
    }


    public void remove() throws Exception{
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
       System.out.println("请输入要删除的ID：");
       int del_id = new Scanner(System.in).nextInt();
       if(check_LinkID(del_id-1) == false)
    	   System.out.println("查找失败。");
       else
       {
    	   MapNode del_map = remove(del_id-1);
    	   System.out.println("查找成功,要删除的ID信息如下：");
    	   System.out.println(del_map.map.toString());
       }
    }
    
    public MapNode remove(int index) throws  Exception{
        if(index<0 || index>size)
        {
            throw  new IndexOutOfBoundsException("超出链表节点范围！");
        }
        MapNode removeNode=null;
        if(index==0){
            //删除头节点
            removeNode=head;
            head=head.next;
        }else if(index==size-1){
            //删除尾节点
            MapNode prevNode=get(index-1);
            removeNode=prevNode.next;
            prevNode.next=null;
            last=prevNode;
        }else {
            //删除中间节点
            MapNode prevNode=get(index-1);
            MapNode nextNode=prevNode.next.next;
            removeNode=prevNode.next;
            prevNode.next=nextNode;
        }
        size--;
        return removeNode;
    }

    public boolean check_LinkID(int id){
    	MapNode temp=head;
    	while (temp!=null)
    	{
    		if(temp.map.linkID==id)
                return true;
    		temp = temp.next;
    	}
        return false;
    }
    
    public void output(){
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
        MapNode temp=head;
        while (temp!=null){
            System.out.println(temp.map.toString());
            temp=temp.next;
        }
    }

    public void find() throws Exception{
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
        System.out.println("请输入要查找的ID：");
        int find_id = new Scanner(System.in).nextInt();
        if(check_LinkID(find_id-1) == false)
     	   System.out.println("查找失败。");
        else
        {
     	   Map find_map = get1(find_id);
     	   System.out.println("查找成功,信息如下：");
     	   System.out.println(find_map.toString());
        }
     }
    public Map get1(int index){
        //判断访问的下标是否超出范围
        if(index<0 || index>=size){
            throw  new IndexOutOfBoundsException("超出数组实际元素范围");
        }
        MapNode temp=head;
    	while (temp!=null)
    	{
    		if(temp.map.linkID==index)
                break;
    		temp = temp.next;
    	}
        return temp.map;
    }
    
    /**
     * 节点对象
     */
    static class MapNode{
        Map map;
        MapNode next;
        public MapNode(Map map){
            this.map=map;
        }
    }

    /**
     * 冒泡排序
     */
    public void bubbleSort(){
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
        if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        int k_flag=0;
        //开始计时
        long start=System.currentTimeMillis();
        for (MapNode p=this.head;p!=null;p=p.next){
            Map temp=null;

            for (MapNode q=p;q!=null;q=q.next){
                if(q.map.linkID<p.map.linkID){
                    temp=p.map;
                    p.map=q.map;
                    q.map=temp;
                    k_flag=1;
                }
            }
            //无交换时说明已经有序
            if (0==k_flag){
                break;
            }
        }
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;
    }
    
    public void quiksort()
    {
    	if(this.head == null && this.last == null)
    	{
    		System.out.println("空间已释放，不可操作。");
    		return;
    	}
    	if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        //开始计时
        long start=System.currentTimeMillis();
        quiksort(this.head, this.size, this.last);
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;
    }
    
    public void quiksort(MapNode head, int size, MapNode last)
    {
    	if (size <= 1)
    		return;
    	MapNode start = head.next;
    	int pivot_val = start.map.linkID;
    	int split_position = 0;
    	MapNode temp0 = start;
    	MapNode temp1 = start.next;
    	if (temp1 == null)
    		return;
    	for (int i = 1; i < size; i ++)
    	{
    		if (temp1 == null)
        		break;
    		if (temp1.map.linkID > pivot_val)
    		{ //放到链表末尾
    			if (temp1 != last)
    			{
    				temp0.next = temp1.next;
    				temp1.next = last.next;
    				last.next = temp1;
    				last = temp1;
    				temp1 = temp0.next;
    			}
    		}
    		else
    		{
    			temp1 = temp1.next;
    			temp0 = temp0.next;
    			split_position ++;
    		}
    	}
    	MapNode pivot_node = start;
    	if (temp0 != start)
    	{
    		head.next = pivot_node.next;
    		temp0.next = pivot_node;
    		pivot_node.next = temp1;
    	}
    	quiksort(head, split_position, temp0);
    	quiksort(pivot_node, size - split_position - 1, last);
    }
    

    public void MapLinkedListclear(){


    	MapNode temp=head;
     	while (temp.next!=null)
     	{
     		MapNode temp1=temp.next;
     		temp.next = temp.next.next;
     		temp1 = null;
     	}
     	head = null;
    	last = null;
        this.size=0;
        this.sort=0;
    }

}
