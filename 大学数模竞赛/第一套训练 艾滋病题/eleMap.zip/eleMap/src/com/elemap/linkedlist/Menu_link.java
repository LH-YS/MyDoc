package com.elemap.linkedlist;

import java.util.Scanner;

import com.elemap.Main;
import com.elemap.list.FileUtils;

public class Menu_link {
	/**
     *  链表列表菜单
     */
    public static void firstMenu() throws Exception {

        System.out.println("请选择服务的种类:");
        System.out.println("\t1.排序");
        System.out.println("\t2.插入");
        System.out.println("\t3.删除");
        System.out.println("\t4.查找");
        System.out.println("\t5.查看");
        System.out.println("\t6.空间释放");
        System.out.println("\t7.更新文件");
        System.out.println("\t0.退出");
        System.out.println("请选择相应序号");
        int select_no=new Scanner(System.in).nextInt();
        switch (select_no){
            case 1:sort_menu();break;
            case 2:Main.mapLinkedList.insert();break;
            case 3:Main.mapLinkedList.remove();break;
            case 4:Main.mapLinkedList.find();break;
            case 5:Main.mapLinkedList.output();break;
            case 6:Main.mapLinkedList.MapLinkedListclear();break;
            case 7:FileUtils_link.writeFile("C:\\Users\\LY\\Desktop\\电子地图\\ORDER_SAVE.txt");
            case 0:System.exit(0);
        }
        firstMenu();
    }

    

    /**
     * 链表排序
     */
    public static void sort_menu(){
        System.out.println("请选择排序文件的方式:");
        System.out.println("\t1.冒泡排序");
        System.out.println("\t2.快速排序_双边循环");
        System.out.println("\t0.退出");
        System.out.println("请选择相应序号");
        int select_no=new Scanner(System.in).nextInt();
        switch (select_no){
            case 1:Main.mapLinkedList.bubbleSort();;break;
            case 2:Main.mapLinkedList.quiksort();;break;
            case 0:return;
        }
    }


}
