package com.elemap.list;

import com.elemap.Main;
import com.elemap.list.FileUtils;

import java.util.Scanner;

public class Menu {

    /**
     * 顺序列表菜单
     */
    public static void firstMenu() throws Exception {

        System.out.println("请选择服务的种类:");
        System.out.println("\t1.排序");
        System.out.println("\t2.插入");
        System.out.println("\t3.删除");
        System.out.println("\t4.查找");
        System.out.println("\t5.查看");
        System.out.println("\t6.空间释放");
        System.out.println("\t7.更新文件");
        System.out.println("\t0.退出");
        System.out.println("请选择相应序号");
        int select_no=new Scanner(System.in).nextInt();
        switch (select_no){
            case 1:sort_menu();break;
            case 2:Main.mapList.insert();break;
            case 3:Main.mapList.delete();break;
            case 4:Main.mapList.find();break;
            case 5:Main.mapList.output();break;
            case 6:Main.mapList.MapListclear();break;
            case 7:FileUtils.writeFile("C:\\Users\\LY\\Desktop\\电子地图\\ORDER_SAVE.txt");
            case 0:System.exit(0);
        }
        firstMenu();
    }

    

    /**
     * 顺序表排序
     */
    public static void sort_menu(){
        System.out.println("请选择排序文件的方式:");
        System.out.println("\t1.冒泡排序");
        System.out.println("\t2.冒泡排序_v2");
        System.out.println("\t3.快速排序_双边循环");
        System.out.println("\t4.快速排序_单边循环");
        System.out.println("\t0.退出");
        System.out.println("请选择相应序号");
        int select_no=new Scanner(System.in).nextInt();
        switch (select_no){
            case 1:
                Main.mapList.bubbleSort();break;
            case 2:Main.mapList.bubbleSort_v2();break;
            case 3:Main.mapList.quickSort();break;
            case 4:Main.mapList.quickSort_1();break;
            case 0:return;
        }
    }



}
