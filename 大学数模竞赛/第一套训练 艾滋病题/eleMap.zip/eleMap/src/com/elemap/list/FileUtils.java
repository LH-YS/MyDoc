package com.elemap.list;

import com.elemap.Main;
import com.elemap.Map;
import com.elemap.list.MapList;

import java.io.*;

public class FileUtils {

	
    public static void readFile(String path) throws Exception {
        InputStream is = new FileInputStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"GBK"));
        String str = null;
        Main.mapList=new MapList(1000);
        while (true) {
            str = reader.readLine();
            if(str!=null && ""!=str)
            {
                Main.mapList.add(changeData(str));
            }
            else
                break;
        }
        is.close();
    }

    public static void writeFile(String path) throws Exception {
    	File file = new File(path);
    	if (!file.exists()) {
    		file.createNewFile();
    	}
    	FileWriter writer = new FileWriter(file , true);
    	BufferedWriter out = new BufferedWriter(writer);
    	for(int i = 0; i < Main.mapList.getSize(); i++)
    	{
    	    out.write("#" + Main.mapList.maps[i].linkID + "; flag=" + Main.mapList.maps[i].flag + "; branch=" + Main.mapList.maps[i].branch + "; dispclass=" + Main.mapList.maps[i].dispclass
    				+ "; roadname=" + Main.mapList.maps[i].roadname + '\''+"\n");
    	}
    	out.flush();
    	out.close();
    }

    public static Map changeData(String str){
        String[] strMap=str.split(";");
        Map map=new Map();
        map.linkID=Integer.parseInt(strMap[0].substring(strMap[0].indexOf("=")+1));
        map.flag=Integer.parseInt(strMap[1].substring(strMap[1].indexOf("=")+1));
        map.branch=Integer.parseInt(strMap[2].substring(strMap[2].indexOf("=")+1));
        map.dispclass=Integer.parseInt(strMap[3].substring(strMap[3].indexOf("=")+1));
        map.roadname=strMap[4].substring(strMap[4].indexOf("=")+1);
        return map;
    }
}
