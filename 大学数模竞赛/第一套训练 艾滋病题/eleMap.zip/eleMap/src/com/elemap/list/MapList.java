package com.elemap.list;

import com.elemap.Main;
import com.elemap.Map;

import java.util.Arrays;
import java.util.Scanner;

/**
 * 地图数组类
 */
public class MapList {

    /**
     * Default initial capacity.
     * 数组默认初始容量
     */
    private static final int DEFAULT_CAPACITY = 10;

    private int size;       //顺序表长度  ，内容长度

    private int sort;         //0表示没有排序,1表示已排序

    Map[] maps;             //数组


    /**
     * 构造函数
     * 实例化
     * @param capacity
     */
    public MapList(int capacity){
        this.maps=new Map[capacity];
        this.size=0;
        this.sort=0;
    }
    public void MapListclear(){
        this.maps=null;
        this.size=0;
        this.sort=0;
    }

    /**
     * 数组添加元素
     * 在数组的末尾添加元素
     * @param map 添加的元素
     */
    public boolean add(Map map)throws Exception{
        //如果实际元素达到数组容量上限，则对数组进行扩容
        if(size>=maps.length){
            resize();//扩容
        }
        maps[size++]=map;
        return true;
    }

    
    public void insert()throws Exception{
    	if(this.maps == null){
            System.out.println("顺序表为空，无法插入。");
            return;
        }
        //建立新的插入对象
    	System.out.println("请输入建立对象的ID");
    	int id = 0,flag = 0,branch = 0,dispclass = 0;
    	int flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_ID=new Scanner(System.in).nextInt();
    		if(select_ID<=this.size)
        		System.out.println(select_ID+"已存在，请重新输入ID");
    		else
    			id = select_ID;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的有无道路名称标识");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_flag=new Scanner(System.in).nextInt();
    		if(select_flag!=0&&select_flag!=1)
        		System.out.println("只能是0或者1，请重新输入");
    		else
    			flag = select_flag;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的道路分叉口数");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_branch=new Scanner(System.in).nextInt();
    		if(select_branch>8||select_branch<0)
        		System.out.println("分岔路口只能是0~7，请重新输入");
    		else
    			branch = select_branch;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的番号");
    	flag1 = 1;
    	while(flag1 == 1)
    	{
    		int select_dispclass=new Scanner(System.in).nextInt();
    		if(select_dispclass>13||select_dispclass<0)
        		System.out.println("番号只能是0~13，请重新输入");
    		else
    			dispclass = select_dispclass;
    			flag1 =0;
    	}
    	System.out.println("请输入建立对象的路名");
    	String select_roadname=new Scanner(System.in).nextLine();
    	Map temp = new Map(id,flag,branch,dispclass,select_roadname);
    	//这里自动采用尾插法 也就是index取值为size
    	insert(temp,size);
    	//插入过后可以再次排序
    	this.sort=0;
    }
    /**
     * 数组插入元素
     * @param map 插入的元素
     * @param index 插入的位置 3 占用一个位置
     * @throws Exception
     */
    public void insert(Map map,int index)throws Exception{
        //判断访问下标是否超出范围  0 6
        if(index<0 || index>this.size){
            throw  new IndexOutOfBoundsException("超出数组实际元素范围");
        }
        size++;
        //如果实际元素达到数组容量上限，则对数组进行扩容
        if(size>=maps.length){
            resize();
        }
        //从右向左循环，将元素逐个向右挪一位
        //递减循环
        //挪空位置，腾位子
        for(int i=size-1;i>=index;i--){
            maps[i+1]=maps[i];
        }
        maps[index]=map;
        
    }

    public void delete() throws Exception{
    	if(this.maps == null){
            System.out.println("顺序表为空，无法删除。");
            return;
        }
       System.out.println("请输入要删除的ID：");
       int del_id = new Scanner(System.in).nextInt();
       if(check_LinkID(del_id-1) == false)
    	   System.out.println("查找失败。");
       else
       {
    	   Map del_map = delete(del_id-1);
    	   System.out.println("查找成功,要删除的ID信息如下：");
    	   System.out.println(del_map.toString());
       }
    }
    /**
     * 数组删除元素
     * @param index 删除的位置
     * @return 删除的元素
     * @throws Exception
     */
    public Map delete(int index) throws Exception{
        //判断访问的下标是否超出范围
        if(index<0 || index>=size){
            throw  new IndexOutOfBoundsException("超出数组实际元素范围");
        }
        Map delMap=this.maps[index];
        //从左向右循环
        for (int i=index;i<size-1;i++){
            this.maps[i]=this.maps[i+1];
        }
        size--;
        return  delMap;
    }

    /**
     * 获取指定位置的元素
     * @param index 下标 索引
     * @return  返回指定元素
     */
    public void find() throws Exception{
    	if(this.maps == null){
            System.out.println("顺序表为空，无法查找。");
            return;
        }
        System.out.println("请输入要查找的ID：");
        int find_id = new Scanner(System.in).nextInt();
        if(check_LinkID(find_id) == false)
     	   System.out.println("查找失败。");
        else
        {
     	   Map find_map = get(find_id);
     	   System.out.println("查找成功,信息如下：");
     	   System.out.println(find_map.toString());
        }
     }
    public Map get(int id){
        //判断访问的下标是否超出范围
        if(id<0 || id>=size){
            throw  new IndexOutOfBoundsException("超出数组实际元素范围");
        }
        Map temp = null;
        for (int i = 0; i <this.size ; i++) {
            if(this.maps[i].linkID==id) {
                temp = this.maps[i];
                break;
            }
        }
        return temp;
    }

    /**
     * 数组扩容
     */
    public void resize(){
        //通过位移计算得到新容量
        int newCapacity=maps.length+(maps.length>>1);
        //将原数组复制到新数组中
        this.maps=Arrays.copyOf(this.maps,newCapacity);
    }

    /**
     * 获取数组的实际长度
     * @return
     */
    public int getSize(){
        return size;
    }

    /**
     * 输出数组
     */
    public void output(){
    	if(this.maps == null){
            System.out.println("顺序表为空，无法输出。");
            return;
        }
        for (int i=0;i<size;i++){
            System.out.println(maps[i]);
        }
        System.out.println("共计："+getSize()+"条数据");
    }

    /**
     * 根据LinkID查找元素
     * @param id
     * @return true元素存在，false不存在
     */
    public boolean check_LinkID(int id){
        for (int i = 0; i <this.size ; i++) {
            if(this.maps[i].linkID==id)
                return true;
        }
        return false;
    }

    /**
     * 冒泡排序
     */
    public void bubbleSort(){
    	if(this.maps == null){
            System.out.println("顺序表为空，无法排序。");
            return;
        }
        if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        //开始计时
        long start=System.currentTimeMillis();
        for (int i = 0; i < Main.mapList.getSize()-1; i++) {
            for (int j = 0; j < Main.mapList.getSize()-i-1 ; j++) {
                Map tmp=null;
                if(maps[j].linkID>maps[j+1].linkID){
                    tmp=maps[j];
                    maps[j]=maps[j+1];
                    maps[j+1]=tmp;
                }
            }
        }
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;
    }

    /**
     *冒泡排序_v2
     */
    public void bubbleSort_v2(){
    	if(this.maps == null){
            System.out.println("顺序表为空，无法排序。");
            return;
        }
        if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        //开始计时
        long start=System.currentTimeMillis();
        for (int i = 0; i < Main.mapList.getSize(); i++) {
            //有序标记，每一轮的初始值都是true
            boolean isSorted=true;
            for (int j = 0; j <Main.mapList.getSize()-i-1 ; j++) {
                Map tempMap=null;
                if (maps[j].linkID>maps[j+1].linkID){
                    tempMap=maps[j];
                    maps[j]=maps[j+1];
                    maps[j+1]=tempMap;

                    //因为有元素进行交换,所以不是有序的，标记变为false
                    isSorted=false;
                }
            }
            if (isSorted){
                break;
            }
        }
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;
    }

    public void quickSort(){
    	if(this.maps == null){
            System.out.println("顺序表为空，无法排序。");
            return;
        }
        if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        //开始计时
        long start=System.currentTimeMillis();
        quickSort(0,this.getSize()-1);
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;

    }
    //双边循环法实现快速排序，代码使用了递归的方式
    public void quickSort(int startIndex,int endIndex){
        //递归结束条件：startIndex大于或等于endIndex时
        if(startIndex>=endIndex){
            return;
        }
        //得到基准元素位置
        int pivotIndex=partition(startIndex,endIndex);
        quickSort(startIndex,pivotIndex-1);
        quickSort(pivotIndex+1,endIndex);
    }

    private int partition(int startIndex,int endIndex){
        //取第一个位置（可以选择随机位置）的元素作为基准元素
        Map pivot=maps[startIndex];
        int left=startIndex;
        int right=endIndex;
        while (left!=right){
            while (left<right && maps[right].linkID>pivot.linkID){
                right--;
            }
            while (left<right && maps[left].linkID<=pivot.linkID){
                left++;
            }
            if(left<right){
                Map temp=maps[left];
                maps[left]=maps[right];
                maps[right]=temp;
            }
        }
        //pivot和指针重合点交换
        maps[startIndex]=maps[left];
        maps[left]=pivot;
        return left;
    }

    public void quickSort_1(){
    	if(this.maps == null){
            System.out.println("顺序表为空，无法排序。");
            return;
        }
        if(this.sort==1){
            System.out.println("\r\n已经排好序，无须再排序\r\n");
            return;
        }
        //开始计时
        long start=System.currentTimeMillis();
        quickSort_1(0,this.getSize()-1);
        //结束计时
        long end=System.currentTimeMillis();
        System.out.println("耗时："+(end-start)+"毫秒");
        this.sort=1;

    }
    public void quickSort_1(int startIndex, int endIndex) {
		// TODO Auto-generated method stub
		// 递归结束条件：startIndex大于或等于endIndex时
		if (startIndex >= endIndex) {
			return;
		}
		// 得到基准元素位置
		int pivotIndex = partition_1(startIndex, endIndex);
		// 根据基准元素，分成两部分进行递归排序
		quickSort_1(startIndex, pivotIndex - 1);// 从尾开始
		quickSort_1(pivotIndex + 1, endIndex);// 从头开始

	}

	private int partition_1(int startIndex, int endIndex) {
		// 取第1 个位置（也可以选择随机位置）的元素作为基准元素
		Map pivot =  maps[startIndex];
		int mark = startIndex;
		for (int i = startIndex + 1; i <= endIndex; i++) {
			
			if (maps[i].linkID < pivot.linkID) {
				mark++;
				Map p = maps[mark];
				maps[mark] = maps[i];
				 maps[i] = p;
			}
		}
		 maps[startIndex] = maps[mark];
		 maps[mark] = pivot;
		return mark;
	}

}
