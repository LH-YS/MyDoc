package com.elemap;

import com.elemap.linkedlist.FileUtils_link;
import com.elemap.linkedlist.MapLinkedList;
import com.elemap.linkedlist.Menu_link;
import com.elemap.list.FileUtils;
import com.elemap.list.MapList;
import com.elemap.list.Menu;

import java.util.Scanner;

public class Main {

    public static MapList mapList;
    public static MapLinkedList mapLinkedList;

    static {
        mapLinkedList=new MapLinkedList();
    }

    public static void main(String[] args) throws Exception {
        menu();

//        //实例化地图数组，现可存放100个地图点
//        MapList mapLs=new MapList(100);
//        //实际存放2 size=2
//        mapLs.add(new Map(1,0,0,11,null));
//        mapLs.add(new Map(5,1,2,11,"国道301"));
//
//
//        mapLs.add(new Map(2,1,1,11,"国道301"));
//
//        mapLs.insert(new Map(11,1,2,11,"国道301"),1);
//        mapLs.delete(1);
//        mapLs.output();
    }

    public static void menu() throws Exception {
        System.out.println("/**************---Weclome---****************/");
        System.out.println("/**********   电子地图信息统计系统   ***********/");
        System.out.println("/********************************************/");
        System.out.println("请选择读取文件方式：");
        System.out.println("\t1.顺序表");
        System.out.println("\t2.链表");
        System.out.println("\t0.退出");
        System.out.println("请选择相应序号");
        int select_no=new Scanner(System.in).nextInt();
        switch (select_no){
            case 1:
                //读取文件
                FileUtils.readFile("C:\\Users\\LY\\Desktop\\电子地图\\ORDER_SAVE.txt");
                Menu.firstMenu();
                break;
            case 2:
            	//读取文件
                FileUtils_link.readFile("C:\\Users\\LY\\Desktop\\电子地图\\ORDER_SAVE.txt");
                Menu_link.firstMenu();
                break;
            case 0:System.exit(0);
        }
    }
}
