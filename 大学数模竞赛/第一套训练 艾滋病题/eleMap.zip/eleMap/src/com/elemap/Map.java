package com.elemap;

/**
 * 地图对象
 * 地图类
 */
public class Map {
    /**
     * linkID
     */
    public int linkID;
    /**
     * 有无道路名称标识,0标识无名称,1表示有
     */
    public int flag;
    /**
     * 道路分叉口数
     */
    public int branch;
    /**
     * 番号
     */
    public int dispclass;
    /**
     * 道路名称
     */
    public String roadname;


    public Map(int linkID, int flag, int branch, int dispclass, String roadname) {
        this.linkID = linkID;
        this.flag = flag;
        this.branch = branch;
        this.dispclass = dispclass;
        this.roadname = roadname;
    }

    public Map() {
    }

    @Override
    public String toString() {
        return "Map{" +
                "linkID=" + linkID +
                ", flag=" + flag +
                ", branch=" + branch +
                ", dispclass=" + dispclass +
                ", roadname='" + roadname + '\'' +
                '}';
    }
}
