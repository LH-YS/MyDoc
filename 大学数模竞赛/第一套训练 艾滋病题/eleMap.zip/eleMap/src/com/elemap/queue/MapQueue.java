package com.elemap.queue;

import com.elemap.Map;

public class MapQueue {
    private Map[] maps;
    private int front;
    private int rear;

    /**
     * 构造函数
     * @param capactiy 初始量
     */
    public MapQueue(int capactiy){
        this.maps=new Map[capactiy];
    }

    /**
     * 入队
     * @param map 入队的元素
     * @throws Exception
     */
    public  void enQueue(Map map) throws  Exception{
        if((rear+1)%this.maps.length==front){
            throw new Exception("队列已满");
        }
        maps[rear]=map;
        rear=(rear+1)%maps.length;
    }

    /**
     * 出队
     * @throws Exception
     */
    public void deQueue() throws Exception{
        if(rear==front){
            throw new Exception("队列已空");
        }
        Map deMap=maps[front];
        front=(front+1)%maps.length;
        return;
    }

    /**
     * 输出队列
     */
    public void output(){
        for (int i=front;i!=rear;i=(i+1)%maps.length){
            System.out.println(maps[i]);
        }
    }

    /**
     *
     */
    public void bubbleSort(){

    }

}
